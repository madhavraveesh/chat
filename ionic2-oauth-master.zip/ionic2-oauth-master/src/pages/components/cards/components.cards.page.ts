import { Component } from '@angular/core';

@Component({
	templateUrl: 'components.cards.html'
})

export class ComponentsCardsPage {

}
