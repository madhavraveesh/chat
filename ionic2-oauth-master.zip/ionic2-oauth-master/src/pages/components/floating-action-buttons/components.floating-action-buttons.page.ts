import { Component } from '@angular/core';

@Component({
	templateUrl: 'components.floating-action-buttons.html'
})

export class ComponentsFloatingActionButtonsPage {

}
