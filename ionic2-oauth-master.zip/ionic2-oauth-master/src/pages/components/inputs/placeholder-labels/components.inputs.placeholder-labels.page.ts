import { Component } from '@angular/core';


@Component({
	templateUrl: 'components.inputs.placeholder-labels.html'
})
export class ComponentsInputsPlaceholderLabelsPage {
}
