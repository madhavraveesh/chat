import { Component } from '@angular/core';

@Component({
	templateUrl: 'components.inputs.fixed-labels.html'
})

export class ComponentsInputsFixedLabelsPage {

}
