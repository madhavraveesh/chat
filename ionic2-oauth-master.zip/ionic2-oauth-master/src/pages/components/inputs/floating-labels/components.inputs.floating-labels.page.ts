import { Component } from '@angular/core';


@Component({
	templateUrl: 'components.inputs.floating-labels.html'
})
export class ComponentsInputsFloatingLabelsPage {
}
