export interface OAuthToken {
	accessToken: string;
	source: string;
}
